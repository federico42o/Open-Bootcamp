# list = [1,452,213,"Hola", "elemento", True, -24, 55,88,299, 477, "JASJSAJA"]


# for x in range (1, len(list)+1):
#     posicion = int(input("ingrese la posicion del elemento"))
#     print(list[posicion])
# print()


# def is_leap(year):
#     leap = False
    
#     if year % 4 ==0 and (year % 400== 0 or year % 100 != 0):
#         leap = True
#     # Write your logic here
#     return leap

# year = int(input())
# print(is_leap(year))

